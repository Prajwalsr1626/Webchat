const Images ={
    praju:require('../Images/prajwal.jpg'),
    logo:require('../Images/logo.png'),
    imput_file:require('../Images/imageuplod.png'),
    wave_hand:require('../Images/ic_wave_hand.png'),
    send:require('../Images/send.png'),
    stiker:require('../Images/sterkar.png'),
    choosefile:require('../Images/icon.png'),
    emoji1:require('../Images/1happy.png'),
    emoji2:require('../Images/2Emoji.png'),
    emoji3:require('../Images/3Emoji.png'),
    emoji4:require('../Images/4Emoji.jpeg'),
    emoji5:require('../Images/5Emoji.png'),
    emoji6:require('../Images/6Emoji.png'),
    mimi1: require('../Images/mimi1.gif'),
    mimi2: require('../Images/mimi2.gif'),
    mimi3: require('../Images/mimi3.gif'),
    mimi4: require('../Images/mimi4.gif'),
    mimi5: require('../Images/mimi5.gif'),
    mimi6: require('../Images/mimi6.gif'),
    mimi7: require('../Images/mimi7.gif'),
    mimi8: require('../Images/mimi8.gif'),
    mimi9: require('../Images/mimi9.gif')
     

}
export default Images