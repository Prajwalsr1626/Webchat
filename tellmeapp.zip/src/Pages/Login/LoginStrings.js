const LoginString=
{
    ID:'id',
    PhotoURL:'photoUrl',
    Name:'nickname',
    Email:'email',
    Password:'image/',
    DOC:'added',
    NODE_MESSAGES: 'messages',
    Description:'Mydescription',
    FirebaseDocumentID:'docid',
    UPLOAD_CHANGED:'state_changed',
    PREFIX_IMAGE:'image/',
    CurrentUserdocKey:''
}
export default LoginString